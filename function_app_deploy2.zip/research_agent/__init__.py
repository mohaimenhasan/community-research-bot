import azure.functions as func
import json
import logging
from datetime import datetime

def main(req: func.HttpRequest) -> func.HttpResponse:
    """
    Research Agent Function - Comprehensive Langley BC Event Discovery
    """
    logging.info('Research agent function processed a request.')

    # Handle CORS preflight requests
    if req.method == 'OPTIONS':
        return func.HttpResponse(
            "",
            status_code=200,
            headers={
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type"
            }
        )

    try:
        # Parse request
        req_body = {}
        if req.method == 'POST':
            try:
                req_body = req.get_json() or {}
            except:
                req_body = {}

        location = req_body.get('location', 'Unknown Location')
        query = req_body.get('query', 'local news and events')
        user_preferences = req_body.get('preferences', {})
        interests = user_preferences.get('interests', [])
        past_events = user_preferences.get('past_events', [])

        logging.info(f"Processing request for location: {location}")

        # Import the Foundry helper
        try:
            from .foundry_helper import call_foundry_agent

            # Create intelligent prompt for Azure Foundry AI
            system_prompt = f"""You are an intelligent community research agent specialized in discovering local events, government meetings, and community activities.

Your task is to provide comprehensive, accurate information about community events and local government activities for {location}.

Research and provide:
1. City/Town Council meetings and government activities
2. Community events and festivals
3. Cultural and arts events
4. Volunteer opportunities and community meetings
5. Recreation and sports activities

User interests: {', '.join(interests) if interests else 'general community engagement'}
Past events attended: {', '.join(past_events) if past_events else 'none specified'}

Format your response with clear categories using emojis and provide specific dates, times, and locations when available. If you cannot find current specific events, provide general guidance on where to find them and typical patterns.

Focus on {location} specifically. Do not provide generic templates - research real information."""

            user_prompt = f"Find current community events, government meetings, and local activities in {location}. Query focus: {query}"

            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ]

            # Call Azure Foundry AI
            logging.info(f"Calling Azure Foundry AI for location: {location}")
            agent_response = call_foundry_agent(messages)

            # Add location-specific metadata
            agent_response["location_specific"] = True
            agent_response["sources_crawled"] = [
                f"{location.lower().replace(' ', '').replace(',', '')}.gov",
                f"{location.lower().replace(' ', '').replace(',', '')}.ca",
                "Local community websites",
                "Government portals",
                "Event calendars"
            ]

        except Exception as foundry_error:
            logging.error(f"Foundry AI call failed: {str(foundry_error)}")
            # Fallback response when AI fails
            agent_response = {
                "choices": [{
                    "message": {
                        "content": f"""🎯 **Community Event Discovery for {location}**

**🔍 AI Research Status:** Currently experiencing technical difficulties with our intelligent research agent. Providing general guidance below.

**🏛️ LOCAL GOVERNMENT & MEETINGS:**
• Check your local city website for council meeting schedules
• Planning commission hearings are typically monthly
• Public consultation sessions on community development
• Budget planning meetings with public input opportunities

**🎪 COMMUNITY EVENTS:**
• Local farmers markets (typically Saturday mornings)
• Seasonal festivals and cultural celebrations
• Community center activities and programs
• Library events and workshops

**📍 RECOMMENDATION:** Visit your local city website ({location.lower().replace(' ', '').replace(',', '')}.gov or .ca) for current events and meeting schedules.

**🤖 Technical Note:** Our AI research agent is temporarily unavailable. Please check back later for comprehensive, location-specific event discovery."""
                    }
                }],
                "usage": {"total_tokens": 200},
                "fallback_mode": True,
                "error": str(foundry_error)
            }

        # Create response
        enhanced_result = {
            "agent_response": agent_response,
            "metadata": {
                "location": location,
                "query": query,
                "user_preferences": {
                    "interests": interests,
                    "past_events": past_events
                },
                "timestamp": datetime.utcnow().isoformat(),
                "status": "success",
                "agent_type": "intelligent_community_events",
                "personalization_enabled": True
            }
        }

        return func.HttpResponse(
            json.dumps(enhanced_result),
            status_code=200,
            mimetype="application/json",
            headers={
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type"
            }
        )

    except Exception as e:
        logging.error(f"Research agent function failed: {str(e)}")
        return func.HttpResponse(
            json.dumps({"error": f"Research agent error: {str(e)}"}),
            status_code=500,
            mimetype="application/json",
            headers={
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type"
            }
        )