import azure.functions as func
import json
import logging
from datetime import datetime

def main(req: func.HttpRequest) -> func.HttpResponse:
    """
    Research Agent Function - Comprehensive Langley BC Event Discovery
    """
    logging.info('Research agent function processed a request.')

    # Handle CORS preflight requests
    if req.method == 'OPTIONS':
        return func.HttpResponse(
            "",
            status_code=200,
            headers={
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type"
            }
        )

    try:
        # Parse request
        req_body = {}
        if req.method == 'POST':
            try:
                req_body = req.get_json() or {}
            except:
                req_body = {}

        location = req_body.get('location', 'Unknown Location')
        query = req_body.get('query', 'local news and events')
        user_preferences = req_body.get('preferences', {})
        interests = user_preferences.get('interests', [])
        past_events = user_preferences.get('past_events', [])

        logging.info(f"Processing request for location: {location}")

        # Import the Foundry helper
        try:
            from .foundry_helper import call_foundry_agent

            # Create intelligent prompt for actual content research
            system_prompt = f"""You are a community research agent that provides ACTUAL, SPECIFIC local information about {location}.

CRITICAL REQUIREMENTS:
1. DO NOT provide status updates or discovery messages
2. DO NOT mention "Research Agent" or "Phase 1" or "pipeline"
3. PROVIDE REAL, actionable community information

TASK: Find and report CURRENT, SPECIFIC information about {location} including:

**🏛️ GOVERNMENT & MUNICIPAL:**
• Current city council meetings with dates/times/agendas
• Recent municipal announcements and public hearings
• Current public consultations and community input opportunities

**🎪 COMMUNITY EVENTS:**
• This week's and next week's community events with specific dates/times/locations
• Ongoing festivals, markets, cultural activities
• Registration deadlines and ticket information

**📰 LOCAL NEWS:**
• Recent local news stories affecting the community
• Infrastructure updates, construction projects, service changes
• Community achievements and local business news

**🏢 PUBLIC SERVICES:**
• Current library programs, recreation center schedules
• Public service updates, facility closures/openings
• Community resources and support programs

USER INTERESTS: {', '.join(interests) if interests else 'general community engagement'}

IMPORTANT: Provide SPECIFIC details with dates, times, locations, and contact information. If you cannot find current specific information, provide guidance on WHERE residents can find this information (specific websites, phone numbers, locations)."""

            user_prompt = f"Find and summarize current real information for {location}. Focus on: {query}. Provide specific details with dates/times when available."

            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ]

            # Call Azure Foundry AI
            logging.info(f"Calling Azure Foundry AI for location: {location}")
            agent_response = call_foundry_agent(messages)

            # Let the agent response go through without hardcoded fallbacks
            logging.info("Azure Foundry Agent response received - using real agent output")

            # Add research agent metadata
            agent_response["location_specific"] = True
            agent_response["research_agent_active"] = True

            # Sources will be dynamically discovered by the AI research agent
            # This represents the agent's actual source discovery capability
            agent_response["discovery_status"] = "sources_identified"
            agent_response["content_categories"] = [
                "Government & Municipal",
                "Community Events",
                "Local News",
                "Public Announcements",
                "Community Organizations"
            ]

        except Exception as foundry_error:
            logging.error(f"Foundry AI call failed: {str(foundry_error)}")
            # Minimal fallback - the agent should be doing the real work
            agent_response = {
                "choices": [{
                    "message": {
                        "content": f"⚠️ **Azure Foundry Agent Error**\n\nOur research agent for {location} is currently experiencing issues.\n\nError: {str(foundry_error)}\n\nPlease try again in a moment for real-time community event discovery."
                    }
                }],
                "usage": {"total_tokens": 50},
                "fallback_mode": True,
                "error": str(foundry_error)
            }

        # Create response
        enhanced_result = {
            "agent_response": agent_response,
            "metadata": {
                "location": location,
                "query": query,
                "user_preferences": {
                    "interests": interests,
                    "past_events": past_events
                },
                "timestamp": datetime.utcnow().isoformat(),
                "status": "success",
                "agent_type": "intelligent_community_events",
                "personalization_enabled": True
            }
        }

        return func.HttpResponse(
            json.dumps(enhanced_result),
            status_code=200,
            mimetype="application/json",
            headers={
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type"
            }
        )

    except Exception as e:
        logging.error(f"Research agent function failed: {str(e)}")
        return func.HttpResponse(
            json.dumps({"error": f"Research agent error: {str(e)}"}),
            status_code=500,
            mimetype="application/json",
            headers={
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type"
            }
        )